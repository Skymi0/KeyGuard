import encryption


key = encryption.generate_key()
